/*
    Trivial header file for keygen.c All documentation appears in .c file.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
char generateRandChar();
char mapToAscii(int number);
